import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import openseespy.opensees as ops

from framekit.geometry import node_id_at
from framekit.constants import PSI_Q2, G_STD


# ============================================================
# FLOOR NODE HELPERS
# ============================================================
def _floor_nodes(geom, floor):
    nfp = geom.num_bays + 1
    return [node_id_at(geom, floor, ix) for ix in range(nfp)]


# ============================================================
# MASS LOADSET
# ============================================================
def build_mass_loadset_from_cases(cases, psi_mass_Q=PSI_Q2):
    import copy

    mass_loads = []

    for key in ("SW", "G"):
        mass_loads += cases.get(key, [])

    if abs(psi_mass_Q) > 1e-15 and "Q" in cases:
        for Ld in cases["Q"]:
            Lc = copy.deepcopy(Ld)
            if Lc.load_type == "triangular":
                if Lc.w1 is not None:
                    Lc.w1 *= psi_mass_Q
                if Lc.w2 is not None:
                    Lc.w2 *= psi_mass_Q
            else:
                Lc.value *= psi_mass_Q
            mass_loads.append(Lc)

    return mass_loads


# ============================================================
# ELEMENT LENGTH
# ============================================================
def _element_length_m(nodes, elements, eid):
    ni, nj, _ = elements[eid]
    x1, y1 = nodes[ni]
    x2, y2 = nodes[nj]
    return float(np.hypot(x2 - x1, y2 - y1))


# ============================================================
# BEAM IDS BY LEVEL
# ============================================================
def get_beam_element_ids_by_level(nodes, elements, geom, level):
    y_level = level * geom.floor_height
    out = []

    for eid, (ni, nj, etype) in elements.items():
        if etype != "beam":
            continue
        if abs(nodes[ni][1] - y_level) < 1e-9 and abs(nodes[nj][1] - y_level) < 1e-9:
            out.append(eid)

    return out


# ============================================================
# FLOOR MASSES
# ============================================================
def compute_floor_masses_kg_from_line_loads(
    geom,
    nodes,
    elements,
    loads_for_mass,
    add_lumped_mass_per_floor_kg=0.0
):
    from framekit.units import _kN_to_N, _kNpm_to_Npm

    floor_masses = {st: 0.0 for st in range(1, geom.num_floors + 1)}

    for st in range(1, geom.num_floors + 1):
        beam_set = set(get_beam_element_ids_by_level(nodes, elements, geom, st))

        for Ld in loads_for_mass:
            if Ld.direction != "vertical":
                continue

            if Ld.load_type == "point" and Ld.node is not None:
                y = nodes[Ld.node][1]
                if abs(y - st * geom.floor_height) < 1e-9:
                    W_N = abs(_kN_to_N(Ld.value))
                    floor_masses[st] += W_N / G_STD
                continue

            if Ld.element is None or Ld.element not in beam_set:
                continue

            L_m = _element_length_m(nodes, elements, Ld.element)

            if Ld.load_type == "uniform":
                w_Npm = abs(_kNpm_to_Npm(Ld.value))
                floor_masses[st] += (w_Npm * L_m) / G_STD

            elif Ld.load_type == "triangular":
                w1 = abs(_kNpm_to_Npm(Ld.w1 or 0.0))
                w2 = abs(_kNpm_to_Npm(Ld.w2 or 0.0))
                w_avg = 0.5 * (w1 + w2)
                floor_masses[st] += (w_avg * L_m) / G_STD

        if add_lumped_mass_per_floor_kg > 0.0:
            floor_masses[st] += add_lumped_mass_per_floor_kg

    return floor_masses


def print_floor_mass_report(floor_masses_kg):
    tot = sum(floor_masses_kg.values())
    print("\n=== MASS REPORT (lumped by floor) ===")
    for st in sorted(floor_masses_kg.keys()):
        print(f"Floor {st:2d}: {floor_masses_kg[st]:.3f} kg")
    print(f"TOTAL MASS: {tot:.3f} kg")
    return tot


# ============================================================
# ASSIGN MASSES TO OPS MODEL
# ============================================================
def ops_assign_floor_masses(nodes, geom, floor_masses_kg, master_nodes=None, tiny_mass_ratio=1.0e-8):
    """
    Important:
    - Main seismic mass goes in X direction (DOF 1)
    - Tiny stabilizing masses are added in DOF 2 and DOF 3
      to avoid singular/undetermined higher modes in 2D frame eigen analysis
    """
    for st in range(1, geom.num_floors + 1):
        m_floor = float(floor_masses_kg.get(st, 0.0))
        m_tiny = max(m_floor * tiny_mass_ratio, 1.0e-9)

        if master_nodes:
            ops.mass(master_nodes[st], m_floor, m_tiny, m_tiny)
        else:
            ids = _floor_nodes(geom, st)
            n_ids = max(len(ids), 1)
            m_per = m_floor / n_ids
            m_tiny_per = max(m_per * tiny_mass_ratio, 1.0e-9)

            for nid in ids:
                ops.mass(nid, m_per, m_tiny_per, m_tiny_per)


# ============================================================
# MODE SHAPE PLOTS
# ============================================================
def plot_mode_deformed_structure(nodes, elements, mode_index, scale=None, title_prefix="Mode Shape"):
    xs = [p[0] for p in nodes.values()]
    ys = [p[1] for p in nodes.values()]
    Lref = max(max(xs) - min(xs), max(ys) - min(ys), 1e-9)

    U = {}
    umax = 0.0

    for nid in nodes.keys():
        ux = float(ops.nodeEigenvector(nid, mode_index, 1))
        uy = float(ops.nodeEigenvector(nid, mode_index, 2))
        try:
            rz = float(ops.nodeEigenvector(nid, mode_index, 3))
        except Exception:
            rz = 0.0

        U[nid] = (ux, uy, rz)
        umax = max(umax, abs(ux), abs(uy))

    if scale is None:
        scale = 0.10 * Lref / max(umax, 1e-12)

    plt.figure(figsize=(10, 7))

    for eid, (ni, nj, _) in elements.items():
        x1, y1 = nodes[ni]
        x2, y2 = nodes[nj]
        plt.plot([x1, x2], [y1, y2], "k--", alpha=0.25)

    for eid, (ni, nj, etype) in elements.items():
        x1, y1 = nodes[ni]
        x2, y2 = nodes[nj]

        ux1, uy1, rz1 = U[ni]
        ux2, uy2, rz2 = U[nj]

        dx = x2 - x1
        dy = y2 - y1
        L = float(np.hypot(dx, dy))
        if L < 1e-12:
            continue

        c = dx / L
        s = dy / L

        u1l = c * ux1 + s * uy1
        v1l = -s * ux1 + c * uy1
        u2l = c * ux2 + s * uy2
        v2l = -s * ux2 + c * uy2

        xi = np.linspace(0.0, L, 40)
        r = xi / L

        ul = (1.0 - r) * u1l + r * u2l

        N1 = 1.0 - 3.0 * r**2 + 2.0 * r**3
        N2 = L * (r - 2.0 * r**2 + r**3)
        N3 = 3.0 * r**2 - 2.0 * r**3
        N4 = L * (-r**2 + r**3)
        vl = N1 * v1l + N2 * rz1 + N3 * v2l + N4 * rz2

        x_def = []
        y_def = []

        for uu, vv, xx in zip(ul, vl, xi):
            xg = x1 + c * xx + scale * (c * uu - s * vv)
            yg = y1 + s * xx + scale * (s * uu + c * vv)
            x_def.append(xg)
            y_def.append(yg)

        plt.plot(x_def, y_def, "b", lw=2)

    plt.axis("equal")
    plt.grid(True, alpha=0.3)
    plt.title(f"{title_prefix} {mode_index} (auto scale={scale:.2e})")
    plt.show()


# ============================================================
# EIGEN ANALYSIS
# ============================================================
def ops_run_eigen_and_print_and_plot(
    geom,
    nodes,
    elements,
    num_modes=3,
    ref_grid_x=0,
    normalize=True,
    plot_floor_shapes=True,
    plot_structure_each_mode=True
):
    num_modes = int(num_modes)

    try:
        eig_raw = ops.eigen("-fullGenLapack", num_modes)
    except Exception:
        eig_raw = ops.eigen(num_modes)

    if eig_raw is None:
        raise RuntimeError("Eigen analysis failed: ops.eigen returned None")

    if np.isscalar(eig_raw):
        eig_raw = [float(eig_raw)]

    lambdas_raw = np.array(eig_raw, dtype=float)
    if lambdas_raw.size == 0:
        raise RuntimeError("Eigen analysis failed: empty eigenvalue list returned")

    print("\nRaw eigenvalues returned by OpenSees:")
    for i, lam in enumerate(lambdas_raw, start=1):
        print(f"  mode {i}: {lam}")

    valid_mask = np.isfinite(lambdas_raw) & (lambdas_raw > 0.0) & (lambdas_raw < 1.0e100)

    if not np.any(valid_mask):
        raise RuntimeError("Eigen analysis failed: no valid positive finite eigenvalues returned")

    lambdas = lambdas_raw[valid_mask]
    valid_mode_ids = [i + 1 for i, ok in enumerate(valid_mask) if ok]

    invalid_count = int(lambdas_raw.size - lambdas.size)
    if invalid_count > 0:
        print(f"⚠️ Ignored {invalid_count} invalid/undetermined eigenvalues.")

    omegas = np.sqrt(lambdas)
    periods = np.where(omegas > 0.0, 2.0 * np.pi / omegas, np.inf)

    try:
        ops.modalProperties()
    except Exception as e:
        print(f"⚠️ modalProperties() warning: {e}")

    floor_nodes = [node_id_at(geom, st, ref_grid_x) for st in range(1, geom.num_floors + 1)]
    floor_heights = np.array([st * geom.floor_height for st in range(1, geom.num_floors + 1)], dtype=float)

    print("\n=== EIGEN ANALYSIS ===")
    for i, mode_id in enumerate(valid_mode_ids):
        print(f"Mode {mode_id}: lambda={lambdas[i]:.6e}  omega={omegas[i]:.6e} rad/s  T={periods[i]:.6f} s")

    shapes = []
    kept_mode_ids = []
    kept_periods = []

    for i, mode_id in enumerate(valid_mode_ids):
        vec = np.array([ops.nodeEigenvector(nid, mode_id, 1) for nid in floor_nodes], dtype=float)

        if not np.all(np.isfinite(vec)):
            print(f"⚠️ Skipping mode {mode_id}: invalid eigenvector values.")
            continue

        if normalize:
            m = np.max(np.abs(vec))
            if m > 0.0:
                vec = vec / m

        shapes.append(vec)
        kept_mode_ids.append(mode_id)
        kept_periods.append(periods[i])

    print("\nMode shapes (X at one node per floor; normalized to max=1):")
    for mode_id, vec in zip(kept_mode_ids, shapes):
        s = "  ".join([f"{v:+.3f}" for v in vec])
        print(f"Mode {mode_id}: [{s}]")

    if plot_floor_shapes and shapes:
        plt.figure(figsize=(6, 6))
        for mode_id, Tmode, vec in zip(kept_mode_ids, kept_periods, shapes):
            plt.plot(vec, floor_heights, marker="o", label=f"Mode {mode_id} (T={Tmode:.3f}s)")
        plt.axvline(0.0, linewidth=1)
        plt.grid(True, alpha=0.3)
        plt.xlabel("Normalized mode shape (X)")
        plt.ylabel("Height [m]")
        plt.title("Mode Shapes (X) by Floor")
        plt.legend()
        plt.show()

    if plot_structure_each_mode:
        for mode_id in kept_mode_ids:
            plot_mode_deformed_structure(
                nodes,
                elements,
                mode_index=mode_id,
                scale=None,
                title_prefix="Mode Shape (Structure)"
            )

    return np.array(kept_periods, dtype=float), shapes


# ============================================================
# MODAL PARTICIPATION
# ============================================================
def modal_participation_table(geom, floor_masses_kg, num_modes):
    floors = list(range(1, geom.num_floors + 1))
    m = np.array([floor_masses_kg[f] for f in floors], dtype=float)
    r = np.ones(len(floors), dtype=float)

    rows = []
    total_mass = np.sum(m)

    for mode in range(1, int(num_modes) + 1):
        try:
            phi = np.array(
                [ops.nodeEigenvector(node_id_at(geom, f, 0), mode, 1) for f in floors],
                dtype=float
            )
        except Exception:
            continue

        if not np.all(np.isfinite(phi)):
            continue

        den = np.sum(m * phi * phi)
        num = np.sum(m * phi * r)

        if abs(den) < 1e-14:
            Gamma = 0.0
            Meff = 0.0
        else:
            Gamma = num / den
            Meff = (num ** 2) / den

        ratio = Meff / total_mass if total_mass > 0 else 0.0
        rows.append([mode, Gamma, Meff, ratio])

    df = pd.DataFrame(rows, columns=["Mode", "Gamma", "M_eff_kg", "Mass_ratio"])
    df["Cum_mass_ratio"] = df["Mass_ratio"].cumsum()
    return df