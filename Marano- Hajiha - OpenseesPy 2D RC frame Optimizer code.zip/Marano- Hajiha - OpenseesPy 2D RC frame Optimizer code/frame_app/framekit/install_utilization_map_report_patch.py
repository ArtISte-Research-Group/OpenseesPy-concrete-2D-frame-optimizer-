from __future__ import annotations

import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
SRC_REPORT = THIS_DIR / "retrofit_optimization_report.py"
SRC_MAIN = THIS_DIR / "main_iterative_jacketing_fixed_with_utilization_maps.py"

if not SRC_REPORT.exists():
    raise FileNotFoundError(f"Cannot find {SRC_REPORT}. Extract the zip and run this script from the extracted folder.")
if not SRC_MAIN.exists():
    raise FileNotFoundError(f"Cannot find {SRC_MAIN}. Extract the zip and run this script from the extracted folder.")

# Project root can be passed as argument, otherwise use current working directory.
if len(sys.argv) > 1:
    project_root = Path(sys.argv[1]).resolve()
else:
    project_root = Path.cwd().resolve()

framekit_dir = project_root / "framekit"
if not framekit_dir.exists():
    # Try parent folders in case the script is launched from framekit or a subfolder.
    p = Path.cwd().resolve()
    candidates = [p, *p.parents]
    found = None
    for c in candidates:
        if (c / "framekit").is_dir():
            found = c
            break
    if found is not None:
        project_root = found
        framekit_dir = found / "framekit"

if not framekit_dir.exists():
    raise RuntimeError(
        "Could not find project framekit folder. Run from your project root, e.g.\n"
        r'cd "C:\Users\arman\Desktop\Work polito\frame_app"' + "\n"
        "then run this script again."
    )

backup_tag = datetime.now().strftime("%Y%m%d_%H%M%S")

def backup_and_copy(src: Path, dst: Path) -> None:
    if dst.exists():
        bak = dst.with_name(dst.name + f".bak_{backup_tag}")
        shutil.copy2(dst, bak)
        print(f"BACKUP: {bak}")
    shutil.copy2(src, dst)
    print(f"UPDATED: {dst}")

backup_and_copy(SRC_REPORT, framekit_dir / "retrofit_optimization_report.py")
# Do not overwrite main.py automatically, because users may have custom filename.
main_dst = project_root / "main_iterative_jacketing_fixed_with_utilization_maps.py"
backup_and_copy(SRC_MAIN, main_dst)

# Delete pycache to force reimport.
for pycache in [framekit_dir / "__pycache__", project_root / "__pycache__"]:
    if pycache.exists():
        shutil.rmtree(pycache, ignore_errors=True)
        print(f"REMOVED: {pycache}")

report_text = (framekit_dir / "retrofit_optimization_report.py").read_text(encoding="utf-8", errors="ignore")
print("\nVerification in installed report file:")
for token in [
    "jacketing_iteration_worst_dfs",
    "def save_member_utilization_map_figure",
    "def save_jacketing_iteration_utilization_maps",
    "def save_jacketed_section_comparison_figures",
]:
    print(f"  {token}: {token in report_text}")

print("\nNext steps:")
print("1) Restart Spyder/Python kernel completely.")
print("2) Run:")
print("   from framekit import retrofit_optimization_report as r")
print("   import inspect")
print("   print(r.__file__)")
print("   print('jacketing_iteration_worst_dfs' in inspect.signature(r.export_retrofit_optimization_report).parameters)")
print("   print(hasattr(r, 'save_jacketing_iteration_utilization_maps'))")
print("   print(hasattr(r, 'save_member_utilization_map_figure'))")
print("3) Use main_iterative_jacketing_fixed_with_utilization_maps.py for the run.")
