import matplotlib.pyplot as plt
import numpy as np

from framekit.geometry import node_id_at


def plot_structure(
    nodes,
    elements,
    geom=None,
    walls=None,
    loads=None,
    title="Structure",
    *,
    load_arrow_scale=0.025,
    load_head_width_scale=0.005,
    load_head_length_scale=0.008,
    load_offset_scale=0.025,
    n_load_arrows=4,
    load_label_fontsize=7,
    stick_horizontal_loads_to_columns=True,
):
    """Plot frame geometry, walls and applied loads.

    Load-plot controls:
    - load_arrow_scale: relative arrow length. Smaller value means smaller arrows.
    - load_head_width_scale / load_head_length_scale: arrow-head size.
    - load_offset_scale: offset for vertical loads on beams and optional non-column loads.
    - n_load_arrows: number of arrows for distributed loads.
    - stick_horizontal_loads_to_columns: if True, horizontal wind/triangular loads
      applied to vertical members are drawn directly on the column line, not shifted
      into the bay.
    """
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_aspect('equal')

    # ------------------------------------------------------------
    # Draw frame elements
    # ------------------------------------------------------------
    for eid, (ni, nj, etype) in elements.items():
        x1, y1 = nodes[ni]
        x2, y2 = nodes[nj]

        color = 'b' if etype == 'beam' else 'r'
        ax.plot([x1, x2], [y1, y2], color, lw=2)

        xm = (x1 + x2) / 2
        ym = (y1 + y2) / 2
        ax.text(
            xm, ym, str(eid), fontsize=8,
            bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="gray", alpha=0.8)
        )

    # ------------------------------------------------------------
    # Draw nodes
    # ------------------------------------------------------------
    for nid, (x, y) in nodes.items():
        ax.plot(x, y, 'ko', ms=4)
        ax.text(x, y + 0.12, str(nid), fontsize=8)

    # ------------------------------------------------------------
    # Draw shear walls
    # ------------------------------------------------------------
    if walls and geom is not None:
        for w in walls:
            n1 = node_id_at(geom, w.floor_bot, w.bay_left - 1)
            n2 = node_id_at(geom, w.floor_bot, w.bay_right - 1)
            n3 = node_id_at(geom, w.floor_top, w.bay_right - 1)
            n4 = node_id_at(geom, w.floor_top, w.bay_left - 1)

            ids = [n1, n2, n3, n4]
            xs = [nodes[n][0] for n in ids] + [nodes[ids[0]][0]]
            ys = [nodes[n][1] for n in ids] + [nodes[ids[0]][1]]
            ax.fill(xs, ys, color='green', alpha=0.25, hatch='///')

    # ------------------------------------------------------------
    # Draw loads
    # ------------------------------------------------------------
    if loads:
        xs_all = [xy[0] for xy in nodes.values()]
        ys_all = [xy[1] for xy in nodes.values()]
        xspan = max(xs_all) - min(xs_all) if xs_all else 1.0
        yspan = max(ys_all) - min(ys_all) if ys_all else 1.0
        Lref = max(xspan, yspan, 1.0)

        load_values = []
        for L in loads:
            if getattr(L, 'load_type', None) == "triangular":
                load_values.append(abs(L.w1 if L.w1 is not None else 0.0))
                load_values.append(abs(L.w2 if L.w2 is not None else 0.0))
            else:
                load_values.append(abs(getattr(L, 'value', 0.0)))

        max_load = max(load_values) if load_values else 1.0
        max_load = max(max_load, 1e-9)

        n_arrows_default = max(1, int(n_load_arrows))

        def load_scale(val):
            return float(load_arrow_scale) * Lref * abs(val) / max_load

        def arrow_style():
            return dict(
                fc='m',
                ec='m',
                length_includes_head=True,
                head_width=float(load_head_width_scale) * Lref,
                head_length=float(load_head_length_scale) * Lref,
                lw=0.9,
            )

        def is_vertical_member(dx_elem, dy_elem):
            return abs(dx_elem) < 1e-9 and abs(dy_elem) > 1e-9

        def is_horizontal_direction(direction):
            return str(direction).strip().lower() not in {"vertical", "y", "global_y", "vertical_y"}

        def label_box():
            return dict(boxstyle="round,pad=0.15", fc="white", ec="m", alpha=0.85)

        for L in loads:
            load_type = getattr(L, 'load_type', None)
            direction = getattr(L, 'direction', '')

            # ----------------------------------------------------
            # POINT LOAD
            # ----------------------------------------------------
            if load_type == "point" and getattr(L, 'node', None) is not None:
                x, y = nodes[L.node]
                val = float(getattr(L, 'value', 0.0))
                mag = load_scale(val)
                sgn = np.sign(val) if abs(val) > 1e-15 else 1.0

                if not is_horizontal_direction(direction):
                    dx, dy = 0.0, sgn * mag
                    tx, ty = x + 0.03 * Lref, y + dy * 1.05
                    label = f"{val:.2f} kN"
                else:
                    dx, dy = sgn * mag, 0.0
                    tx, ty = x + dx * 1.05, y + 0.03 * Lref
                    label = f"{val:.2f} kN"

                ax.arrow(x, y, dx, dy, **arrow_style())
                ax.text(tx, ty, label, fontsize=load_label_fontsize, color='m', bbox=label_box())

            # ----------------------------------------------------
            # UNIFORM ELEMENT LOAD
            # ----------------------------------------------------
            elif load_type == "uniform" and getattr(L, 'element', None) is not None:
                ni, nj, etype = elements[L.element]
                x1, y1 = nodes[ni]
                x2, y2 = nodes[nj]

                dx_elem = x2 - x1
                dy_elem = y2 - y1
                Le = np.hypot(dx_elem, dy_elem)
                if Le < 1e-12:
                    continue

                n_arrows = n_arrows_default
                val = float(getattr(L, 'value', 0.0))
                mag = load_scale(val)
                sgn = np.sign(val) if abs(val) > 1e-15 else 1.0

                if not is_horizontal_direction(direction):
                    # Vertical loads on horizontal beams: draw slightly above the beam.
                    if abs(dy_elem) < 1e-9:
                        y_base = max(y1, y2) + float(load_offset_scale) * Lref
                        ax.plot([x1, x2], [y_base, y_base], color='m', lw=1.0, alpha=0.8)
                        for i in range(n_arrows):
                            t = (i + 0.5) / n_arrows
                            xi = x1 + t * dx_elem
                            ax.arrow(xi, y_base, 0.0, sgn * mag, **arrow_style())
                        tx = (x1 + x2) / 2 + 0.02 * Lref
                        ty = y_base + 0.04 * Lref
                        ax.text(tx, ty, f"{val:.2f} kN/m", fontsize=load_label_fontsize, color='m', bbox=label_box())
                    else:
                        ax_dx, ax_dy = 0.0, sgn * mag
                        for i in range(n_arrows):
                            t = (i + 0.5) / n_arrows
                            xi = x1 + t * dx_elem
                            yi = y1 + t * dy_elem
                            ax.arrow(xi, yi, ax_dx, ax_dy, **arrow_style())
                        xm = (x1 + x2) / 2
                        ym = (y1 + y2) / 2
                        ax.text(xm + 0.02 * Lref, ym + ax_dy + 0.04 * Lref * np.sign(ax_dy if abs(ax_dy) > 1e-15 else 1.0),
                                f"{val:.2f} kN/m", fontsize=load_label_fontsize, color='m', bbox=label_box())
                else:
                    # Horizontal load. If it is on a vertical member/column, keep the
                    # load reference line directly on the member and start arrows there.
                    ax_dx, ax_dy = sgn * mag, 0.0
                    vertical = is_vertical_member(dx_elem, dy_elem)
                    side_offset = 0.0 if (vertical and stick_horizontal_loads_to_columns) else float(load_offset_scale) * Lref * np.sign(ax_dx if abs(ax_dx) > 1e-15 else 1.0)

                    ax.plot([x1 + side_offset, x2 + side_offset], [y1, y2], color='m', lw=1.0, alpha=0.8)
                    for i in range(n_arrows):
                        t = (i + 0.5) / n_arrows
                        xi = x1 + t * dx_elem + side_offset
                        yi = y1 + t * dy_elem
                        ax.arrow(xi, yi, ax_dx, ax_dy, **arrow_style())

                    xm = (x1 + x2) / 2 + side_offset
                    ym = (y1 + y2) / 2
                    ax.text(xm + ax_dx + 0.02 * Lref * np.sign(ax_dx if abs(ax_dx) > 1e-15 else 1.0),
                            ym + 0.03 * Lref, f"{val:.2f} kN/m", fontsize=load_label_fontsize, color='m', bbox=label_box())

            # ----------------------------------------------------
            # TRIANGULAR ELEMENT LOAD
            # ----------------------------------------------------
            elif load_type == "triangular" and getattr(L, 'element', None) is not None:
                ni, nj, etype = elements[L.element]
                x1, y1 = nodes[ni]
                x2, y2 = nodes[nj]

                dx_elem = x2 - x1
                dy_elem = y2 - y1
                Le = np.hypot(dx_elem, dy_elem)
                if Le < 1e-12:
                    continue

                n_arrows = n_arrows_default
                w1 = float(L.w1 if L.w1 is not None else 0.0)
                w2 = float(L.w2 if L.w2 is not None else 0.0)

                if not is_horizontal_direction(direction):
                    # Vertical triangular loads on horizontal beams: draw above beam.
                    if abs(dy_elem) < 1e-9:
                        y_base = max(y1, y2) + float(load_offset_scale) * Lref
                        ax.plot([x1, x2], [y_base, y_base], color='m', lw=1.0, alpha=0.8)
                        for i in range(n_arrows):
                            t = (i + 0.5) / n_arrows
                            xi = x1 + t * dx_elem
                            w = (1 - t) * w1 + t * w2
                            mag = load_scale(w)
                            sgn = np.sign(w) if abs(w) > 1e-15 else 1.0
                            ax.arrow(xi, y_base, 0.0, sgn * mag, **arrow_style())
                        xm = (x1 + x2) / 2
                        ax.text(xm + 0.03 * Lref, y_base + 0.04 * Lref,
                                f"tri: {w1:.2f} -> {w2:.2f} kN/m",
                                fontsize=load_label_fontsize, color='m', bbox=label_box())
                    else:
                        for i in range(n_arrows):
                            t = (i + 0.5) / n_arrows
                            xi = x1 + t * dx_elem
                            yi = y1 + t * dy_elem
                            w = (1 - t) * w1 + t * w2
                            mag = load_scale(w)
                            sgn = np.sign(w) if abs(w) > 1e-15 else 1.0
                            ax.arrow(xi, yi, 0.0, sgn * mag, **arrow_style())
                        xm = (x1 + x2) / 2
                        ym = (y1 + y2) / 2
                        ax.text(xm + 0.03 * Lref, ym + 0.03 * Lref,
                                f"tri: {w1:.2f} -> {w2:.2f} kN/m",
                                fontsize=load_label_fontsize, color='m', bbox=label_box())
                else:
                    # Horizontal triangular wind load. This is the corrected part:
                    # for vertical columns, side_offset is forced to zero, so the
                    # magenta load reference line is on the red column line and the
                    # arrows start from the column itself.
                    vertical = is_vertical_member(dx_elem, dy_elem)
                    ref_val = w1 if abs(w1) >= abs(w2) else w2
                    ref_sign = np.sign(ref_val) if abs(ref_val) > 1e-15 else 1.0
                    side_offset = 0.0 if (vertical and stick_horizontal_loads_to_columns) else float(load_offset_scale) * Lref * ref_sign

                    ax.plot([x1 + side_offset, x2 + side_offset], [y1, y2], color='m', lw=1.0, alpha=0.8)

                    for i in range(n_arrows):
                        t = (i + 0.5) / n_arrows
                        xi = x1 + t * dx_elem + side_offset
                        yi = y1 + t * dy_elem
                        w = (1 - t) * w1 + t * w2
                        mag = load_scale(w)
                        sgn = np.sign(w) if abs(w) > 1e-15 else 1.0
                        ax.arrow(xi, yi, sgn * mag, 0.0, **arrow_style())

                    xm = (x1 + x2) / 2 + side_offset
                    ym = (y1 + y2) / 2
                    # Put label just to the side of the member so it does not cover the column.
                    label_shift = 0.02 * Lref * ref_sign
                    ax.text(xm + label_shift, ym + 0.03 * Lref,
                            f"tri: {w1:.2f} -> {w2:.2f} kN/m",
                            fontsize=load_label_fontsize, color='m', bbox=label_box())

    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    plt.show()
