import sys
import os
import inspect
import numpy as np
import pandas as pd

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

frame_app_dir = os.path.join(current_dir, "frame_app")
if os.path.isdir(frame_app_dir):
    sys.path.insert(0, frame_app_dir)

from framekit.geometry import ask_geometry, generate_nodes, generate_elements
from framekit.plotting import plot_structure
from framekit.section_library import ask_sections_rc, plot_selected_rc_sections, plot_jacketed_section_comparisons
from framekit.loads import ask_structure_type, ask_material, compute_self_weight, ask_loads_by_cases
from framekit.combinations import build_eurocode_combinations, print_combinations_detailed
from framekit.walls import ask_shear_walls, ask_shear_wall_section
from framekit.opensees_model import ops_build_model, ops_apply_combo_loads, ops_run_static
from framekit.units import _MPa_to_Pa
from framekit.static_analysis import (
    get_node_disps,
    compute_story_drifts,
    drifts_to_dataframe,
    plot_deformed_shape,
)
from framekit.diagrams import (
    plot_structure_NVM,
    plot_all_combos_NVM,
    collect_member_force_diagrams_for_report,
)


from framekit.ec2_checks import (
    ask_ec2_materials_default_or_custom,
    run_combo_and_check_all,
    worst_table_to_dataframe,
    export_ec2_worst_table_colored,
    plot_verification_table,
    plot_utilization_on_structure,
    add_stirrup_columns_to_worst_table,
)

from framekit.dynamics import (
    build_mass_loadset_from_cases,
    compute_floor_masses_kg_from_line_loads,
    print_floor_mass_report,
    ops_assign_floor_masses,
    ops_run_eigen_and_print_and_plot,
    modal_participation_table,
)

from framekit.response_spectrum import (
    ask_ec8_spectrum_params,
    build_ec8_spectrum_for_periods,
    build_ec8_plot_spectrum,
    plot_ec8_spectrum,
    run_response_spectrum_analysis,
    rsa_drifts_to_dataframe,
    export_response_spectrum_results,
    combine_two_directional_rsa_results,
    export_directional_response_spectrum_results,
)

from framekit.planar_directions import (
    clone_geom_for_direction,
    clone_nodes_for_direction,
    clone_elements_for_direction,
)

from framekit.ec8_drift_checks import (
    ask_ec8_drift_check_params,
    compute_story_heights,
    ec8_damage_limitation_drifts_from_rsa,
    check_ec8_drift_limits,
    summarize_ec8_drift_check,
    export_ec8_drift_check,
)

from framekit.time_history import (
    ask_time_history_params,
    run_multiple_time_histories,
    plot_time_history_response,
    export_multiple_time_history_results,
)

from framekit.performance_summary import (
    build_story_performance_table,
    build_story_failures_table,
    build_member_performance_table,
    build_member_failures_table,
    build_global_performance_summary,
    export_performance_summary_results,
)

from framekit.constants import PSI_Q2

from framekit.retrofit_recommendation import (
    recommend_story_retrofits,
    recommend_member_retrofits,
    build_retrofit_priority_table,
    export_retrofit_recommendations,)

from framekit.retrofit_optimizer import (
    DEFAULT_UNIT_COSTS,
    ask_retrofit_cost_parameters,
    ask_max_global_candidates,
    optimize_shear_wall_positions,
    optimize_global_retrofit_strategy,
    build_global_optimization_dataset,
    export_global_optimization_dataset,
    optimize_concrete_jacketing,
    make_jacketed_element_sections,
    run_ec2_member_assessment,
    estimate_jacketing_cost,
    plot_shear_wall_retrofit_layout,
    plot_jacketed_members,
    plot_final_retrofit_utilization,
)

from framekit.retrofit_optimization_report import (
    export_retrofit_optimization_report,
)



# ============================================================
# Robust exact N/V/M collection helpers for report export
# ============================================================
def _first_existing_column_for_report(df, names):
    if df is None or getattr(df, "empty", True):
        return None
    lookup = {str(c).strip().lower(): c for c in df.columns}
    for name in names:
        key = str(name).strip().lower()
        if key in lookup:
            return lookup[key]
    return None


def _critical_member_ids_for_report_nvm(df, max_members=6):
    """Return the most critical element IDs from an EC2/member table.

    This is used to guarantee that the report has real OpenSees N/V/M
    diagrams even when no member is still failing after retrofit.  The list is
    sorted by largest available utilization ratio.
    """
    if df is None or getattr(df, "empty", True):
        return []
    ele_col = _first_existing_column_for_report(df, ["Element", "ElementID", "Member", "Member ID"])
    if ele_col is None:
        return []
    eta_col = _first_existing_column_for_report(
        df,
        [
            "eta", "Static_EC2_Utilization", "Utilization", "Worst eta", "Max_Eta",
            "Max_EC2_Utilization", "Final_Max_EC2_Utilization",
        ],
    )
    d = df.copy()
    d[ele_col] = pd.to_numeric(d[ele_col], errors="coerce")
    d = d.dropna(subset=[ele_col])
    if d.empty:
        return []
    if eta_col is not None:
        d[eta_col] = pd.to_numeric(d[eta_col], errors="coerce")
        d = d.sort_values(eta_col, ascending=False, na_position="last")
    out = []
    for val in d[ele_col].tolist():
        try:
            eid = int(val)
        except Exception:
            continue
        if eid not in out:
            out.append(eid)
        if len(out) >= int(max_members):
            break
    return out


def _nvm_result_dataframe_for_report(result, governing_combo=""):
    if result is None:
        return None
    try:
        _xg, _yg, n_arr, v_arr, m_arr, length_m, _c, _s = result
        npts = len(n_arr)
        df = pd.DataFrame({
            "x_m": np.linspace(0.0, float(length_m), npts),
            "N_kN": np.asarray(n_arr, dtype=float) / 1000.0,
            "V_kN": np.asarray(v_arr, dtype=float) / 1000.0,
            "M_kNm": np.asarray(m_arr, dtype=float) / 1000.0,
        })
        if governing_combo:
            df["Governing_Combo"] = str(governing_combo)
        return df
    except Exception:
        return None


def _run_model_for_report_nvm_stage(
    *,
    nodes,
    elements,
    geom,
    Ec_Pa,
    Es_Pa,
    column_sec,
    beam_sec,
    ops_build_model_fn,
    walls,
    wall_tw_mm,
    wall_E_Pa,
    use_rigid_diaphragm=False,
    element_sections=None,
):
    """Build the model for an N/V/M report stage, compatible with old signatures."""
    try:
        sig = inspect.signature(ops_build_model_fn)
        supports_element_sections = "element_sections" in sig.parameters
    except Exception:
        supports_element_sections = True

    kwargs = dict(
        geom=geom,
        use_rigid_diaphragm=bool(use_rigid_diaphragm),
        walls=walls,
        wall_tw_mm=float(wall_tw_mm),
        wall_E_Pa=float(wall_E_Pa),
    )
    if supports_element_sections:
        kwargs["element_sections"] = element_sections

    try:
        return ops_build_model_fn(
            nodes,
            elements,
            Ec_Pa,
            Es_Pa,
            column_sec,
            beam_sec,
            **kwargs,
        )
    except TypeError:
        # Fallback for older opensees_model.py versions that do not accept
        # element_sections.  The report will still get exact post-wall diagrams.
        kwargs.pop("element_sections", None)
        return ops_build_model_fn(
            nodes,
            elements,
            Ec_Pa,
            Es_Pa,
            column_sec,
            beam_sec,
            **kwargs,
        )


def _collect_member_force_diagrams_by_uls_scan(
    *,
    nodes,
    elements,
    combos,
    combo_names,
    Ec_Pa,
    Es_Pa,
    column_sec,
    beam_sec,
    geom,
    ops_build_model_fn,
    ops_apply_combo_loads_fn,
    ops_run_static_fn,
    target_member_ids,
    stage_specs,
    npts=80,
):
    """Fallback exact N/V/M collector for the Word report.

    The primary collector uses the governing combination stored in the EC2
    worst table.  Some EC2 tables do not keep that column, so the primary
    collector may return no data.  This fallback scans all ULS combinations,
    runs the real OpenSees model for each retrofit stage, and stores the exact
    station-by-station diagram from the most demanding ULS combination for
    every requested member.
    """
    try:
        from framekit.diagrams import _nvm_arrays_for_element
    except Exception as exc:
        print(f"WARNING: exact N/V/M fallback is unavailable: {exc}")
        return {}

    target_ids = []
    for eid in target_member_ids or []:
        try:
            eid_int = int(eid)
        except Exception:
            continue
        if eid_int in elements and eid_int not in target_ids:
            target_ids.append(eid_int)
    if not target_ids:
        return {}

    all_names = [str(c) for c in (combo_names or []) if str(c) in combos]
    uls_names = [c for c in all_names if str(c).upper().startswith("ULS")]
    scan_names = uls_names if uls_names else all_names
    if not scan_names:
        return {}

    out = {}
    for stage_name, spec in (stage_specs or {}).items():
        if spec is None:
            continue
        best_by_member = {int(eid): (None, -np.inf, "") for eid in target_ids}
        for cname in scan_names:
            try:
                _run_model_for_report_nvm_stage(
                    nodes=nodes,
                    elements=elements,
                    geom=geom,
                    Ec_Pa=Ec_Pa,
                    Es_Pa=Es_Pa,
                    column_sec=column_sec,
                    beam_sec=beam_sec,
                    ops_build_model_fn=ops_build_model_fn,
                    walls=spec.get("walls", None),
                    wall_tw_mm=spec.get("wall_tw_mm", 200.0),
                    wall_E_Pa=spec.get("wall_E_Pa", 30e9),
                    use_rigid_diaphragm=spec.get("use_rigid_diaphragm", False),
                    element_sections=spec.get("element_sections", None),
                )
                ops_apply_combo_loads_fn(nodes, elements, combos[cname]["loads"])
                ok = ops_run_static_fn()
                if ok != 0:
                    continue
                for eid in target_ids:
                    result = _nvm_arrays_for_element(eid, elements, combos[cname]["loads"], nodes, npts=npts)
                    df = _nvm_result_dataframe_for_report(result, governing_combo=cname)
                    if df is None or df.empty:
                        continue
                    # Select a real governing combination.  The score is a
                    # transparent demand proxy using the absolute station maxima.
                    max_m = pd.to_numeric(df["M_kNm"], errors="coerce").abs().max()
                    max_v = pd.to_numeric(df["V_kN"], errors="coerce").abs().max()
                    max_n = pd.to_numeric(df["N_kN"], errors="coerce").abs().max()
                    score = float(max_m if pd.notna(max_m) else 0.0)
                    score += 0.01 * float(max_v if pd.notna(max_v) else 0.0)
                    score += 0.001 * float(max_n if pd.notna(max_n) else 0.0)
                    if score > best_by_member[int(eid)][1]:
                        best_by_member[int(eid)] = (df, score, cname)
            except Exception as exc:
                print(f"WARNING: report N/V/M fallback skipped {stage_name} / {cname}: {exc}")
                continue

        for eid, (df, score, cname) in best_by_member.items():
            if df is not None and np.isfinite(score):
                out.setdefault(int(eid), {})[str(stage_name)] = df

    return out


if __name__ == "__main__":
    # storage for global summary
    df_worst = None
    rsa_results = None
    dir_results = None
    df_ec8_single_all = None
    df_ec8_dir_all = None
    batch_th = None
    df_dir_env = None
    df_worst_after_sw = None
    df_worst_final = None
    member_fail_after_sw = None
    member_fail_final = None
    jacket_cost = None
    failed_member_ids = []
    sw_opt_df = None
    optimized_walls = None
    jacketing_iteration_worst_dfs = []
    member_force_diagrams = None
    optimization_dataset_df = None

    # 1) Structure type
    stype = ask_structure_type()

    # 2) Geometry
    geom = ask_geometry()
    nodes = generate_nodes(geom)
    elements = generate_elements(geom)

    plot_structure(nodes, elements, geom=geom, title="Structure (IDs)")

    # 3) Shear walls
    walls = ask_shear_walls(geom)

    wall_tw_mm = 200.0
    wall_E_MPa = 30000.0
    wall_density = 2500.0

    if walls:
        wall_tw_mm, wall_E_MPa, wall_density = ask_shear_wall_section()
        plot_structure(
            nodes,
            elements,
            geom=geom,
            walls=walls,
            title="Structure + Shear Walls"
        )

    # 4) Sections
    if stype == "rc":
        column_sec, beam_sec = ask_sections_rc()
        ec2mat = ask_ec2_materials_default_or_custom()
    else:
        print("\nSteel section input is not connected yet in this modular version.")
        print("For now, using RC section input block temporarily.")
        column_sec, beam_sec = ask_sections_rc()
        ec2mat = None

    print("\nColumn section:")
    print(column_sec)
    print("\nBeam section:")
    print(beam_sec)

    plot_sections_now = input("\nPlot selected RC beam/column sections? (y/n) [y]: ").strip().lower() or "y"
    if plot_sections_now == "y":
        plot_selected_rc_sections(column_sec, beam_sec)

    # 5) Material
    material = ask_material("Concrete" if stype == "rc" else "Steel")

    # 6) Load cases
    gravity_loads = compute_self_weight(elements, material, beam_sec, column_sec)
    cases = ask_loads_by_cases(nodes, elements, geom)
    cases["SW"] = gravity_loads

    print("\n=== LOAD CASE SUMMARY ===")
    for k, v in cases.items():
        print(f"{k}: {len(v)} loads")

    print("\nShowing each load case separately...")
    for case_name in ["SW", "G", "Q", "W+", "W-"]:
        if cases.get(case_name):
            plot_structure(
                nodes,
                elements,
                geom=geom,
                walls=walls,
                loads=cases[case_name],
                title=f"Structure + Loads : {case_name}"
            )

    # 7) Combinations
    combos = build_eurocode_combinations(cases)
    names = print_combinations_detailed(combos)

    # 8) Run all combinations
    Ec_Pa = _MPa_to_Pa(material.E)
    Es_Pa = 200e9
    wall_E_Pa = _MPa_to_Pa(wall_E_MPa)

    print("\n--- Running static analysis for ALL combinations ---")

    all_drift_tables = []
    results_ok = []
    results_failed = []

    for cname in names:
        print(f"\nRunning: {cname}")
        loads_combo = combos[cname]["loads"]

        ops_build_model(
            nodes,
            elements,
            Ec_Pa,
            Es_Pa,
            column_sec,
            beam_sec,
            geom=geom,
            use_rigid_diaphragm=False,
            walls=walls,
            wall_tw_mm=wall_tw_mm,
            wall_E_Pa=wall_E_Pa
        )

        ops_apply_combo_loads(nodes, elements, loads_combo)

        ok = ops_run_static()
        if ok != 0:
            print(f"❌ Failed: {cname}")
            results_failed.append(cname)
            continue

        print(f"✔ Success: {cname}")
        results_ok.append(cname)

        U = get_node_disps(nodes)
        drifts = compute_story_drifts(geom, nodes, U)

        df = drifts_to_dataframe(drifts, cname)
        all_drift_tables.append(df)

        if cname.startswith("ULS"):
            plot_deformed_shape(
                geom,
                nodes,
                elements,
                scale=None,
                title=f"Deformed Shape - {cname}"
            )

    # 9) Summary
    print("\n=== STATIC ANALYSIS SUMMARY ===")
    print(f"Successful combinations: {len(results_ok)}")
    print(f"Failed combinations: {len(results_failed)}")

    if results_ok:
        print("\nSuccessful:")
        for cname in results_ok:
            print(f"  - {cname}")

    if results_failed:
        print("\nFailed:")
        for cname in results_failed:
            print(f"  - {cname}")

    # 10) Drift tables
    if all_drift_tables:
        df_all = pd.concat(all_drift_tables, ignore_index=True)

        print("\n=== MAX STORY DRIFTS ===")
        print(df_all.to_string(index=False))

        df_all.to_csv("story_drifts.csv", index=False)
        print("\n✔ Drift table exported: story_drifts.csv")
    else:
        df_all = None

    # 11) EC2 checks
    if stype == "rc":
        run_checks = input("\nRun EC2 checks for ULS combinations? (y/n): ").strip().lower()
        if run_checks == "y":
            checks_by_combo = {}

            for cname in names:
                if not cname.startswith("ULS"):
                    continue

                print(f"\nChecking: {cname}")
                loads_combo = combos[cname]["loads"]

                checks, ok = run_combo_and_check_all(
                    nodes,
                    elements,
                    loads_combo,
                    Ec_Pa,
                    Es_Pa,
                    column_sec,
                    beam_sec,
                    ec2mat,
                    ops_build_model,
                    ops_apply_combo_loads,
                    ops_run_static,
                    geom=geom,
                    use_rigid_diaphragm=False,
                    walls=walls,
                    wall_tw_mm=wall_tw_mm,
                    wall_E_Pa=wall_E_Pa
                )

                if ok != 0 or checks is None:
                    print(f"❌ Check failed for {cname}")
                    continue

                checks_by_combo[cname] = checks
                print(f"✔ Check completed for {cname}")

            if checks_by_combo:
                df_worst = worst_table_to_dataframe(checks_by_combo)
                
                df_worst = add_stirrup_columns_to_worst_table(
    df_worst,
    beam_sec=beam_sec,
    column_sec=column_sec,
    elements=elements
)

                print("\n=== EC2 WORST UTILIZATION TABLE ===")
                print(df_worst.to_string(index=False))

                show_table = input("Show colored verification table? (y/n): ").strip().lower()
                if show_table == "y":
                    plot_verification_table(
                        checks_by_combo,
                        title="EC2 Verification (ULS worst eta per member)",
                        max_rows=40
                    )

                show_structure_map = input("Show utilization colored on structure? (y/n): ").strip().lower()
                if show_structure_map == "y":
                    plot_utilization_on_structure(
                        nodes,
                        elements,
                        checks_by_combo,
                        title="Utilization map (ULS worst eta)"
                    )

                export_ec2_worst_table_colored(
                    df_worst,
                    filename="ec2_worst_utilization.xlsx"
                )

    # 13) N/V/M menu
    print("\n--- N/V/M diagrams menu ---")
    print("1) Plot N/V/M for ONE combination")
    print("2) Plot N/V/M for ALL combinations")
    print("3) Skip diagrams")
    opt = input("Select option (1/2/3): ").strip()

    if opt == "1":
        for i, cname in enumerate(names, start=1):
            print(f"{i:2d}) {cname}")

        idx = int(input(f"Choose combination (1..{len(names)}): ").strip())
        cname = names[idx - 1]
        loads_combo = combos[cname]["loads"]

        ops_build_model(
            nodes,
            elements,
            Ec_Pa,
            Es_Pa,
            column_sec,
            beam_sec,
            geom=geom,
            use_rigid_diaphragm=False,
            walls=walls,
            wall_tw_mm=wall_tw_mm,
            wall_E_Pa=wall_E_Pa
        )
        ops_apply_combo_loads(nodes, elements, loads_combo)
        ok = ops_run_static()

        if ok == 0:
            plot_structure_NVM(
                nodes,
                elements,
                loads_combo,
                combo_name=cname,
                npts=60
            )
        else:
            print("❌ Analysis failed for selected combination.")

    elif opt == "2":
        plot_all_combos_NVM(
            nodes,
            elements,
            combos,
            names,
            Ec_Pa,
            Es_Pa,
            column_sec,
            beam_sec,
            geom,
            ops_build_model,
            ops_apply_combo_loads,
            ops_run_static,
            walls=walls,
            wall_tw_mm=wall_tw_mm,
            wall_E_Pa=wall_E_Pa,
            npts=60
        )

    # 14) Linear dynamic analysis: masses + eigen + response spectrum + time history
    run_dynamics = input("\nGo to dynamic analysis now? (y/n): ").strip().lower()
    if run_dynamics == "y":
        psi_mass_Q = float(input(f"Mass live-load factor psi [recommended {PSI_Q2}]: ").strip() or PSI_Q2)
        extra_mass_floor = float(input("Additional lumped mass per floor [kg] (0 if none): ").strip() or 0.0)

        use_diaphragm = input("Use rigid diaphragm per floor? (y/n): ").strip().lower() == "y"

        loads_for_mass = build_mass_loadset_from_cases(cases, psi_mass_Q=psi_mass_Q)
        floor_masses = compute_floor_masses_kg_from_line_loads(
            geom,
            nodes,
            elements,
            loads_for_mass,
            add_lumped_mass_per_floor_kg=extra_mass_floor
        )

        print_floor_mass_report(floor_masses)

        master_nodes = ops_build_model(
            nodes,
            elements,
            Ec_Pa,
            Es_Pa,
            column_sec,
            beam_sec,
            geom=geom,
            use_rigid_diaphragm=use_diaphragm,
            walls=walls,
            wall_tw_mm=wall_tw_mm,
            wall_E_Pa=wall_E_Pa
        )

        ops_assign_floor_masses(
            nodes,
            geom,
            floor_masses,
            master_nodes=(master_nodes if use_diaphragm else None)
        )

        nmodes = int(input("Number of eigen modes to compute: ").strip())
        plot_floor_shapes = input("Plot floor mode-shape curves? (y/n): ").strip().lower() == "y"
        plot_struct_modes = input("Plot full deformed structure for each mode? (y/n): ").strip().lower() == "y"

        periods, shapes = ops_run_eigen_and_print_and_plot(
            geom,
            nodes,
            elements,
            num_modes=nmodes,
            ref_grid_x=0,
            normalize=True,
            plot_floor_shapes=plot_floor_shapes,
            plot_structure_each_mode=plot_struct_modes
        )

        df_modal_part = modal_participation_table(geom, floor_masses, len(periods))
        print("\n=== MODAL PARTICIPATION TABLE ===")
        print(df_modal_part.to_string(index=False))

        df_modal_part.to_csv("modal_participation.csv", index=False)
        print("\n✔ Modal participation exported: modal_participation.csv")

        df_periods = pd.DataFrame({
            "Mode": list(range(1, len(periods) + 1)),
            "Period [s]": periods
        })
        df_periods.to_csv("modal_periods.csv", index=False)
        print("✔ Modal periods exported: modal_periods.csv")

        run_rsa = input("\nRun EC8 response spectrum analysis? (y/n): ").strip().lower()
        if run_rsa == "y":
            rsa_params = ask_ec8_spectrum_params()

            master_nodes = ops_build_model(
                nodes,
                elements,
                Ec_Pa,
                Es_Pa,
                column_sec,
                beam_sec,
                geom=geom,
                use_rigid_diaphragm=use_diaphragm,
                walls=walls,
                wall_tw_mm=wall_tw_mm,
                wall_E_Pa=wall_E_Pa
            )

            ops_assign_floor_masses(
                nodes,
                geom,
                floor_masses,
                master_nodes=(master_nodes if use_diaphragm else None)
            )

            periods, shapes = ops_run_eigen_and_print_and_plot(
                geom,
                nodes,
                elements,
                num_modes=nmodes,
                ref_grid_x=0,
                normalize=True,
                plot_floor_shapes=False,
                plot_structure_each_mode=False
            )

            T_rsa, Sa_rsa = build_ec8_spectrum_for_periods(periods, rsa_params)
            T_plot, Sa_plot = build_ec8_plot_spectrum(rsa_params)

            show_spec_plot = input("Plot EC8 spectrum? (y/n): ").strip().lower()
            if show_spec_plot == "y":
                plot_ec8_spectrum(T_plot, Sa_plot, title="EC8 Response Spectrum")

            rsa_results = run_response_spectrum_analysis(
                geom=geom,
                nodes=nodes,
                elements=elements,
                periods=periods,
                spectrum_T=T_rsa,
                spectrum_Sa=Sa_rsa,
                direction=rsa_params["direction"],
                damping_ratio=rsa_params["damping_ratio"],
                combo_method=rsa_params["combo_method"],
                num_modes=len(periods)
            )

            if rsa_results is not None:
                df_rsa_drifts = rsa_drifts_to_dataframe(rsa_results["story_drifts"], case_name="RSA")
                print("\n=== RESPONSE SPECTRUM STORY DRIFTS ===")
                print(df_rsa_drifts.to_string(index=False))

                df_rsa_drifts.to_csv("response_spectrum_drifts.csv", index=False)
                print("\n✔ RSA drift table exported: response_spectrum_drifts.csv")

                print("\n=== RSA BASE SHEAR ===")
                print(f"Base shear (direction {rsa_params['direction']}): {rsa_results['base_shear']:.3f} N")

                export_response_spectrum_results(
                    rsa_results,
                    filename="response_spectrum_results.xlsx"
                )

                run_dir_combo = input(
                    "\nRun EC8 orthogonal directional combination (100/30) using planar X/Y clone models? (y/n): "
                ).strip().lower()

                drift_check_input = None
                run_drift_check = input("Run EC8 drift limit checks? (y/n): ").strip().lower()

                if run_drift_check == "y":
                    drift_check_input = ask_ec8_drift_check_params()

                if run_dir_combo == "y":
                    rsa_params_xy = dict(rsa_params)
                    rsa_params_xy["direction"] = 1

                    # X model
                    master_nodes_x = ops_build_model(
                        nodes,
                        elements,
                        Ec_Pa,
                        Es_Pa,
                        column_sec,
                        beam_sec,
                        geom=geom,
                        use_rigid_diaphragm=use_diaphragm,
                        walls=walls,
                        wall_tw_mm=wall_tw_mm,
                        wall_E_Pa=wall_E_Pa
                    )

                    ops_assign_floor_masses(
                        nodes,
                        geom,
                        floor_masses,
                        master_nodes=(master_nodes_x if use_diaphragm else None)
                    )

                    periods_x, _ = ops_run_eigen_and_print_and_plot(
                        geom,
                        nodes,
                        elements,
                        num_modes=nmodes,
                        ref_grid_x=0,
                        normalize=True,
                        plot_floor_shapes=False,
                        plot_structure_each_mode=False
                    )

                    T_rsa_x, Sa_rsa_x = build_ec8_spectrum_for_periods(periods_x, rsa_params_xy)

                    rsa_x = run_response_spectrum_analysis(
                        geom=geom,
                        nodes=nodes,
                        elements=elements,
                        periods=periods_x,
                        spectrum_T=T_rsa_x,
                        spectrum_Sa=Sa_rsa_x,
                        direction=1,
                        damping_ratio=rsa_params_xy["damping_ratio"],
                        combo_method=rsa_params_xy["combo_method"],
                        num_modes=len(periods_x)
                    )

                    # Y planar clone
                    geom_y = clone_geom_for_direction(geom, "Y")
                    nodes_y = clone_nodes_for_direction(nodes, "Y")
                    elements_y = clone_elements_for_direction(elements, "Y")

                    master_nodes_y = ops_build_model(
                        nodes_y,
                        elements_y,
                        Ec_Pa,
                        Es_Pa,
                        column_sec,
                        beam_sec,
                        geom=geom_y,
                        use_rigid_diaphragm=use_diaphragm,
                        walls=walls,
                        wall_tw_mm=wall_tw_mm,
                        wall_E_Pa=wall_E_Pa
                    )

                    ops_assign_floor_masses(
                        nodes_y,
                        geom_y,
                        floor_masses,
                        master_nodes=(master_nodes_y if use_diaphragm else None)
                    )

                    periods_y, _ = ops_run_eigen_and_print_and_plot(
                        geom_y,
                        nodes_y,
                        elements_y,
                        num_modes=nmodes,
                        ref_grid_x=0,
                        normalize=True,
                        plot_floor_shapes=False,
                        plot_structure_each_mode=False
                    )

                    T_rsa_y, Sa_rsa_y = build_ec8_spectrum_for_periods(periods_y, rsa_params_xy)

                    rsa_y = run_response_spectrum_analysis(
                        geom=geom_y,
                        nodes=nodes_y,
                        elements=elements_y,
                        periods=periods_y,
                        spectrum_T=T_rsa_y,
                        spectrum_Sa=Sa_rsa_y,
                        direction=1,
                        damping_ratio=rsa_params_xy["damping_ratio"],
                        combo_method=rsa_params_xy["combo_method"],
                        num_modes=len(periods_y)
                    )

                    dir_results = combine_two_directional_rsa_results(
                        rsa_x,
                        rsa_y,
                        orthogonal_factor=0.30
                    )

                    df_dir_env = rsa_drifts_to_dataframe(
                        dir_results["envelope"]["story_drifts"],
                        case_name="RSA_DIR_ENVELOPE"
                    )

                    print("\n=== DIRECTIONAL RSA DRIFTS (ENVELOPE) ===")
                    print(df_dir_env.to_string(index=False))

                    df_dir_env.to_csv("response_spectrum_directional_drifts.csv", index=False)
                    print("\n✔ Directional RSA drift table exported: response_spectrum_directional_drifts.csv")

                    export_directional_response_spectrum_results(
                        dir_results,
                        filename="response_spectrum_directional_results.xlsx"
                    )

                    if drift_check_input is not None:
                        story_heights = compute_story_heights(geom)

                        dls_drifts = ec8_damage_limitation_drifts_from_rsa(
                            dir_results["envelope"]["story_drifts"],
                            nu=drift_check_input["nu"]
                        )

                        all_ec8_dir_tables = []

                        for nse_class in drift_check_input["nse_classes"]:
                            df_ec8_drift = check_ec8_drift_limits(
                                drift_m=dls_drifts,
                                story_heights_m=story_heights,
                                limit_ratio=drift_check_input["limit_ratios"][nse_class],
                                case_name="EC8_DLS_DIR",
                                nse_class=nse_class
                            )

                            print(f"\n=== EC8 DRIFT CHECK (DIRECTIONAL ENVELOPE) : {nse_class} ===")
                            print(df_ec8_drift.to_string(index=False))

                            summary = summarize_ec8_drift_check(df_ec8_drift)
                            print("\n=== EC8 DRIFT CHECK SUMMARY ===")
                            print(f"Status: {'OK' if summary['ok'] else 'FAIL'}")
                            print(f"Failed stories: {summary['num_failed']}")
                            print(f"Worst story: {summary['worst_story']}")
                            print(f"Worst drift ratio: {summary['worst_ratio']:.6f}")
                            print(f"Worst utilization: {summary['worst_utilization']:.3f}")

                            all_ec8_dir_tables.append(df_ec8_drift)

                        if all_ec8_dir_tables:
                            df_ec8_dir_all = pd.concat(all_ec8_dir_tables, ignore_index=True)
                            export_ec8_drift_check(
                                df_ec8_dir_all,
                                filename="ec8_drift_check_directional.xlsx"
                            )

                elif drift_check_input is not None:
                    story_heights = compute_story_heights(geom)

                    dls_drifts = ec8_damage_limitation_drifts_from_rsa(
                        rsa_results["story_drifts"],
                        nu=drift_check_input["nu"]
                    )

                    all_ec8_single_tables = []

                    for nse_class in drift_check_input["nse_classes"]:
                        df_ec8_drift = check_ec8_drift_limits(
                            drift_m=dls_drifts,
                            story_heights_m=story_heights,
                            limit_ratio=drift_check_input["limit_ratios"][nse_class],
                            case_name="EC8_DLS_RSA",
                            nse_class=nse_class
                        )

                        print(f"\n=== EC8 DRIFT CHECK (SINGLE RSA DIRECTION) : {nse_class} ===")
                        print(df_ec8_drift.to_string(index=False))

                        summary = summarize_ec8_drift_check(df_ec8_drift)
                        print("\n=== EC8 DRIFT CHECK SUMMARY ===")
                        print(f"Status: {'OK' if summary['ok'] else 'FAIL'}")
                        print(f"Failed stories: {summary['num_failed']}")
                        print(f"Worst story: {summary['worst_story']}")
                        print(f"Worst drift ratio: {summary['worst_ratio']:.6f}")
                        print(f"Worst utilization: {summary['worst_utilization']:.3f}")

                        all_ec8_single_tables.append(df_ec8_drift)

                    if all_ec8_single_tables:
                        df_ec8_single_all = pd.concat(all_ec8_single_tables, ignore_index=True)
                        export_ec8_drift_check(
                            df_ec8_single_all,
                            filename="ec8_drift_check_single_direction.xlsx"
                        )

        run_th = input("\nRun linear time-history analysis? (y/n): ").strip().lower()
        if run_th == "y":
            th_params = ask_time_history_params()

            master_nodes = ops_build_model(
                nodes,
                elements,
                Ec_Pa,
                Es_Pa,
                column_sec,
                beam_sec,
                geom=geom,
                use_rigid_diaphragm=use_diaphragm,
                walls=walls,
                wall_tw_mm=wall_tw_mm,
                wall_E_Pa=wall_E_Pa
            )

            ops_assign_floor_masses(
                nodes,
                geom,
                floor_masses,
                master_nodes=(master_nodes if use_diaphragm else None)
            )

            periods_th, _ = ops_run_eigen_and_print_and_plot(
                geom,
                nodes,
                elements,
                num_modes=nmodes,
                ref_grid_x=0,
                normalize=True,
                plot_floor_shapes=False,
                plot_structure_each_mode=False
            )

            batch_th = run_multiple_time_histories(
                geom=geom,
                nodes=nodes,
                elements=elements,
                periods=periods_th,
                records=th_params["records"],
                direction=th_params["direction"],
                damping_ratio=th_params["damping_ratio"],
                mode_i=th_params["mode_i"],
                mode_j=th_params["mode_j"],
                dt_analysis=th_params["dt_analysis"],
            )

            print("\n=== MULTI-RECORD TIME-HISTORY SUMMARY ===")
            print(batch_th["summary"].to_string(index=False))

            print("\n=== MULTI-RECORD PEAK STORY DRIFTS ===")
            print(batch_th["peak_drifts_all"].to_string(index=False))

            print("\n=== ENVELOPE STORY DRIFTS ===")
            print(batch_th["envelope_drifts_df"].to_string(index=False))

            batch_th["summary"].to_csv("time_history_batch_summary.csv", index=False)
            batch_th["peak_drifts_all"].to_csv("time_history_batch_peak_drifts.csv", index=False)
            batch_th["envelope_drifts_df"].to_csv("time_history_batch_envelope_drifts.csv", index=False)

            print("\n✔ TH batch summary exported: time_history_batch_summary.csv")
            print("✔ TH batch peak drifts exported: time_history_batch_peak_drifts.csv")
            print("✔ TH batch envelope drifts exported: time_history_batch_envelope_drifts.csv")

            show_th_plots = input("Plot roof displacement and base shear histories for each record? (y/n): ").strip().lower()
            if show_th_plots == "y":
                for rec_name, res in batch_th["results_by_record"].items():
                    if len(res["roof_disp_history"]):
                        plot_time_history_response(
                            res["time"],
                            res["roof_disp_history"],
                            ylabel="Roof displacement [m]",
                            title=f"Linear TH - Roof displacement - {rec_name}"
                        )
                    if len(res["base_shear_history"]):
                        plot_time_history_response(
                            res["time"],
                            res["base_shear_history"],
                            ylabel="Base shear [N]",
                            title=f"Linear TH - Base shear - {rec_name}"
                        )

            export_multiple_time_history_results(
                batch_th,
                filename="time_history_batch_results.xlsx"
            )

    # 15) Global performance summary
    run_perf_summary = input("\nBuild global performance summary (static + RSA + TH)? (y/n): ").strip().lower()
    if run_perf_summary == "y":
        static_uls_df = None
        if df_all is not None and not df_all.empty and "Case" in df_all.columns:
            static_uls_df = df_all[df_all["Case"].astype(str).str.startswith("ULS", na=False)].copy()
            if static_uls_df.empty:
                static_uls_df = df_all.copy()

        rsa_single_df = None
        if rsa_results is not None:
            rsa_single_df = rsa_drifts_to_dataframe(rsa_results["story_drifts"], case_name="RSA")

        rsa_dir_df = df_dir_env.copy() if df_dir_env is not None else None

        th_env_df = None
        if batch_th is not None:
            th_env_df = batch_th["envelope_drifts_df"].copy()

        story_perf_df = build_story_performance_table(
            static_drifts_df=static_uls_df,
            rsa_single_drifts_df=rsa_single_df,
            rsa_dir_drifts_df=rsa_dir_df,
            th_envelope_drifts_df=th_env_df,
            ec8_single_df=df_ec8_single_all,
            ec8_dir_df=df_ec8_dir_all,
        )

        story_fail_df = build_story_failures_table(story_perf_df)

        member_perf_df = build_member_performance_table(
            ec2_worst_df=df_worst,
            rsa_single_results=rsa_results,
            rsa_dir_results=dir_results,
            batch_th=batch_th,
        )

        member_fail_df = build_member_failures_table(member_perf_df)

        global_summary_df = build_global_performance_summary(
            story_perf_df=story_perf_df,
            member_perf_df=member_perf_df,
        )

        if global_summary_df is not None and not global_summary_df.empty:
            print("\n=== GLOBAL PERFORMANCE SUMMARY ===")
            print(global_summary_df.to_string(index=False))

        if story_perf_df is not None and not story_perf_df.empty:
            print("\n=== STORY PERFORMANCE TABLE ===")
            print(story_perf_df.to_string(index=False))

        if story_fail_df is not None and not story_fail_df.empty:
            print("\n=== STORY FAILURES TABLE ===")
            print(story_fail_df.to_string(index=False))

        if member_perf_df is not None and not member_perf_df.empty:
            print("\n=== MEMBER PERFORMANCE TABLE ===")
            print(member_perf_df.to_string(index=False))

        if member_fail_df is not None and not member_fail_df.empty:
            print("\n=== MEMBER FAILURES TABLE ===")
            print(member_fail_df.to_string(index=False))

        export_performance_summary_results(
            story_perf_df=story_perf_df,
            story_fail_df=story_fail_df,
            member_perf_df=member_perf_df,
            member_fail_df=member_fail_df,
            global_summary_df=global_summary_df,
            filename="performance_summary.xlsx",
        )
    # 16) Retrofit optimization: shear walls first, then concrete jacketing
    run_retrofit_opt = input("\nRun retrofit optimization? (y/n): ").strip().lower()

    if run_retrofit_opt == "y":
        if "story_fail_df" not in locals():
            story_fail_df = None
        if "member_fail_df" not in locals():
            member_fail_df = None

        # --------------------------------------------
        # A) Get failed drift stories
        # --------------------------------------------
        failed_stories = []
        if story_fail_df is not None and not story_fail_df.empty and "Story" in story_fail_df.columns:
            failed_stories = (
                pd.to_numeric(story_fail_df["Story"], errors="coerce")
                .dropna()
                .astype(int)
                .unique()
                .tolist()
            )

        if failed_stories:
            print("\nFailed drift stories:")
            print(failed_stories)
        else:
            print("\nNo failed drift stories detected from performance summary.")

        # --------------------------------------------
        # B-D) Global retrofit optimization
        # --------------------------------------------
        # The optimizer now compares complete strategies:
        #   wall layout + required jacketing + total retrofit cost.
        # Cost is the primary objective; drift, EC2 member safety,
        # constructability and jacketing limits are constraints/penalties.
        drift_limit_ratio = 0.005
        max_walls_per_layout = min(2, int(getattr(geom, "num_bays", 2)))
        wall_layout_mode = "hybrid"
        wall_thicknesses = [150.0, 200.0, 250.0, 300.0]

        # Runtime control: the user chooses how many screened wall layouts
        # enter the expensive global EC2 + jacketing stage. This prevents the
        # default run from becoming an exhaustive many-hour dataset run.
        max_global_candidates = ask_max_global_candidates(default=20)

        retrofit_cost_parameters = ask_retrofit_cost_parameters(DEFAULT_UNIT_COSTS)

        print("\nRunning GLOBAL cost-minimizing retrofit optimization...")
        print(f"  Primary objective: minimum total retrofit cost")
        print(f"  Drift limit ratio: {drift_limit_ratio:.5f}")
        print(f"  Max wall segments per trial layout: {max_walls_per_layout}")
        print(f"  Vertical layout search mode: {wall_layout_mode}")
        print(f"  Wall thickness candidates [mm]: {wall_thicknesses}")
        if max_global_candidates is None:
            print("  Global wall candidates evaluated: ALL screened candidates plus no-new-wall option")
        else:
            print(f"  Global wall candidates evaluated: best {max_global_candidates} screened candidates plus no-new-wall option")

        global_opt_df = optimize_global_retrofit_strategy(
            nodes=nodes,
            elements=elements,
            geom=geom,
            combos=combos,
            combo_names=names,
            Ec_Pa=Ec_Pa,
            Es_Pa=Es_Pa,
            column_sec=column_sec,
            beam_sec=beam_sec,
            ec2mat=ec2mat,
            ops_build_model=ops_build_model,
            ops_apply_combo_loads=ops_apply_combo_loads,
            ops_run_static=ops_run_static,
            base_walls=walls,
            wall_tw_mm=wall_tw_mm,
            wall_E_Pa=wall_E_Pa,
            use_rigid_diaphragm=False,
            drift_limit_ratio=drift_limit_ratio,
            failed_stories=failed_stories if failed_stories else None,
            thicknesses_mm=wall_thicknesses,
            max_walls_per_layout=max_walls_per_layout,
            wall_layout_mode=wall_layout_mode,
            include_no_new_wall_candidate=True,
            max_global_candidates=max_global_candidates,
            unit_costs=retrofit_cost_parameters,
        )

        if global_opt_df is None or global_opt_df.empty:
            print("\nNo global retrofit candidates were generated.")
            optimized_walls = walls
            optimized_wall_tw_mm = wall_tw_mm
            optimized_wall_E_Pa = wall_E_Pa
            df_worst_after_sw = None
            df_worst_final = None
            member_fail_after_sw = None
            member_fail_final = None
            jacketed_element_sections = None
            all_jacketed_member_ids = []
            jacketing_rows = []
            member_jacketing_report = None
            jacket_cost = None
            jacketing_iteration_worst_dfs = []
            sw_opt_df = None
        else:
            internal_cols = [
                "_candidate", "_drifts", "_baseline_drifts", "_walls",
                "_df_worst_after_walls", "_member_perf_after_walls", "_member_fail_after_walls",
                "_cj_opt_df", "_df_worst_final", "_member_fail_final", "_element_sections",
                "_member_report", "_jacket_cost", "_jacketing_iteration_worst_dfs",
            ]
            show_cols = [c for c in [
                "Global_Rank", "Candidate_ID", "Description", "Complete_Feasible",
                "Search_Max_Global_Candidates", "Search_Candidates_Sent_To_Global_Stage",
                "Drift_Utilization", "Member_Failures_After_Walls", "Jacketing_Required",
                "Final_Max_EC2_Utilization", "Final_Failed_Members",
                "Wall_Cost", "Jacketing_Cost", "Total_Retrofit_Cost",
                "Constructability_Class", "Penalty_Jacketing_Limit", "Global_Objective_Score",
            ] if c in global_opt_df.columns]
            print("\n=== GLOBAL RETROFIT OPTIMIZATION RESULTS ===")
            print(global_opt_df[show_cols].to_string(index=False))

            top5_cols = [c for c in [
                "Global_Rank", "Selected", "Candidate_ID", "Complete_Feasible",
                "Wall_Cost", "Jacketing_Cost", "Total_Retrofit_Cost",
                "Drift_Utilization", "Final_Max_EC2_Utilization", "Final_Failed_Members",
                "Constructability_Class",
            ] if c in global_opt_df.columns]
            print("\n=== TOP 5 COMPLETE RETROFIT ALTERNATIVES FOR REPORT ===")
            print(global_opt_df.head(5)[top5_cols].to_string(index=False))

            global_export_df = global_opt_df.drop(columns=internal_cols, errors="ignore")
            global_export_df.to_csv("retrofit_global_optimization.csv", index=False)
            global_export_df.head(5).to_csv("retrofit_top5_alternatives.csv", index=False)

            # Step 1 toward a research/ML workflow: save every evaluated
            # complete retrofit strategy in a clean dataset format.
            optimization_dataset_df = build_global_optimization_dataset(
                global_opt_df,
                structure_id="current_structure",
                include_cost_assumptions=True,
            )
            if optimization_dataset_df is not None and not optimization_dataset_df.empty:
                optimization_dataset_df.to_csv("global_retrofit_optimization_dataset_later_ML.csv", index=False)
                try:
                    optimization_dataset_df.to_excel("global_retrofit_optimization_dataset_later_ML.xlsx", index=False)
                    print("✔ Exported: global_retrofit_optimization_dataset_later_ML.xlsx")
                except Exception as exc:
                    print(f"⚠ Could not export XLSX optimization dataset: {exc}")

            print("\n✔ Exported: retrofit_global_optimization.csv")
            print("✔ Exported: retrofit_top5_alternatives.csv")
            if optimization_dataset_df is not None and not optimization_dataset_df.empty:
                print("✔ Exported: global_retrofit_optimization_dataset_later_ML.csv")

            best_global = global_opt_df.iloc[0]
            best_sw = best_global.get("_candidate", None)
            optimized_walls = best_global.get("_walls", list(walls or []))
            optimized_wall_tw_mm = float(getattr(best_sw, "wall_tw_mm", wall_tw_mm)) if best_sw is not None else wall_tw_mm
            optimized_wall_E_Pa = float(getattr(best_sw, "wall_E_Pa", wall_E_Pa)) if best_sw is not None else wall_E_Pa

            df_worst_after_sw = best_global.get("_df_worst_after_walls", None)
            member_fail_after_sw = best_global.get("_member_fail_after_walls", None)
            df_worst_final = best_global.get("_df_worst_final", df_worst_after_sw)
            member_fail_final = best_global.get("_member_fail_final", member_fail_after_sw)
            jacketed_element_sections = best_global.get("_element_sections", None)
            member_jacketing_report = best_global.get("_member_report", None)
            jacket_cost = best_global.get("_jacket_cost", None)
            jacketing_iteration_worst_dfs = best_global.get("_jacketing_iteration_worst_dfs", []) or []
            cj_opt_df = best_global.get("_cj_opt_df", pd.DataFrame())

            if cj_opt_df is not None and not getattr(cj_opt_df, "empty", True):
                jacketing_rows = cj_opt_df.drop(
                    columns=["_element_sections", "_df_worst", "_member_perf", "_member_fail", "_member_report", "_original_df_worst", "_original_member_fail"],
                    errors="ignore"
                ).to_dict("records")
            else:
                jacketing_rows = []

            all_jacketed_member_ids = [
                int(x) for x in str(best_global.get("Jacketed_Members", "")).split(",")
                if str(x).strip()
            ]
            failed_member_ids = list(all_jacketed_member_ids)

            # Use the selected global table as the selected wall/strategy table for report compatibility.
            sw_opt_df = global_opt_df.copy()

            print("\nSelected global retrofit strategy:")
            print(f"  Candidate: {best_global.get('Candidate_ID', '')}")
            print(f"  Wall layout: {best_global.get('Description', '')}")
            print(f"  Complete feasible: {best_global.get('Complete_Feasible', '')}")
            print(f"  Wall cost: {float(best_global.get('Wall_Cost', 0.0)):.2f}")
            print(f"  Jacketing cost: {float(best_global.get('Jacketing_Cost', 0.0)):.2f}")
            print(f"  Total retrofit cost: {float(best_global.get('Total_Retrofit_Cost', 0.0)):.2f}")
            print(f"  Final failed members: {best_global.get('Final_Failed_Members', '')}")

            if best_sw is not None:
                plot_shear_wall_retrofit_layout(
                    nodes,
                    elements,
                    geom,
                    base_walls=walls,
                    selected_candidate=best_sw,
                    title="Global Optimized Retrofit Layout - Selected Shear Walls",
                )

            if member_jacketing_report is not None and not getattr(member_jacketing_report, "empty", True):
                print("\n=== PER-MEMBER JACKETING DECISION REPORT ===")
                print(member_jacketing_report.to_string(index=False))
                member_jacketing_report.to_csv("retrofit_jacketing_member_report.csv", index=False)
                print("✔ Exported: retrofit_jacketing_member_report.csv")

            if member_fail_after_sw is not None and not getattr(member_fail_after_sw, "empty", True):
                print("\n=== MEMBERS FAILING AFTER SELECTED WALL LAYOUT ===")
                print(member_fail_after_sw.to_string(index=False))
            else:
                print("\nNo member failures after selected wall layout.")

            if member_fail_final is not None and not getattr(member_fail_final, "empty", True):
                print("\n=== MEMBERS STILL FAILING AFTER GLOBAL RETROFIT STRATEGY ===")
                fail_cols = [c for c in [
                    "Element", "Type", "eta", "etaV", "eta_NM",
                    "Static_EC2_Utilization", "NEd_kN", "VEd_kN", "MEd_kNm",
                ] if c in member_fail_final.columns]
                print(member_fail_final[fail_cols].to_string(index=False))
            else:
                print("\n✔ All members verified after selected global retrofit strategy.")

            if df_worst_final is not None and not getattr(df_worst_final, "empty", True):
                plot_final_retrofit_utilization(
                    nodes, elements, df_worst_final,
                    title="Final Member Utilization After Global Retrofit Strategy",
                )
                export_ec2_worst_table_colored(
                    df_worst_final,
                    filename="ec2_worst_utilization_after_retrofit.xlsx"
                )
                print("✔ Exported: ec2_worst_utilization_after_retrofit.xlsx")

            if all_jacketed_member_ids:
                plot_jacketed_members(
                    nodes, elements, all_jacketed_member_ids,
                    title="Concrete Jacketing Layout - Global Cost-Selected Members",
                )
                plot_jacketed_sections_now = input(
                    "\nPlot before/after RC sections for jacketed members? (y/n) [y]: "
                ).strip().lower() or "y"
                if plot_jacketed_sections_now == "y" and jacketed_element_sections is not None:
                    plot_jacketed_section_comparisons(
                        elements=elements,
                        column_sec=column_sec,
                        beam_sec=beam_sec,
                        jacketed_element_sections=jacketed_element_sections,
                        jacketed_member_ids=all_jacketed_member_ids,
                    )

        # --------------------------------------------
        # E) Professional retrofit report
        # --------------------------------------------
        make_report = input("\nGenerate professional retrofit report (Excel + Word if python-docx is installed)? (y/n) [y]: ").strip().lower() or "y"
        if make_report == "y":
            print("\nGenerating professional retrofit report...")
            logo_candidates = [
                os.path.join(current_dir, "Logo_PoliTo_dal_2021_blu.png"),
                os.path.join(os.getcwd(), "Logo_PoliTo_dal_2021_blu.png"),
                os.path.join(os.getcwd(), "retrofit_report", "Logo_PoliTo_dal_2021_blu.png"),
            ]
            logo_path = next((p for p in logo_candidates if os.path.exists(p)), "Logo_PoliTo_dal_2021_blu.png")
            jacketing_trials_df = pd.DataFrame(jacketing_rows) if "jacketing_rows" in locals() and jacketing_rows else None

            # Build exact station-by-station N/V/M data for report diagrams.
            # The report should not reconstruct force diagrams from only the
            # EC2 worst NEd/VEd/MEd ordinates; it should use the same OpenSees
            # force recovery logic used by the interactive N/V/M plots.
            member_force_diagrams = None
            try:
                target_nvm_members = set()
                for _df in [member_fail_after_sw, member_fail_final]:
                    if _df is not None and not getattr(_df, "empty", True) and "Element" in _df.columns:
                        target_nvm_members.update(
                            pd.to_numeric(_df["Element"], errors="coerce").dropna().astype(int).tolist()
                        )
                if "all_jacketed_member_ids" in locals():
                    target_nvm_members.update(int(e) for e in all_jacketed_member_ids)

                # Also add the most critical members from the EC2 worst tables.
                # This makes the final-decision section meaningful even when the
                # selected retrofit has no remaining failed members.
                for _df in [df_worst_after_sw, df_worst_final]:
                    target_nvm_members.update(_critical_member_ids_for_report_nvm(_df, max_members=6))

                target_nvm_member_list = sorted(int(e) for e in target_nvm_members if int(e) in elements)[:12]

                nvm_stage_specs = {
                    "After_Walls": {
                        "df_worst": df_worst_after_sw,
                        "walls": optimized_walls,
                        "wall_tw_mm": optimized_wall_tw_mm,
                        "wall_E_Pa": optimized_wall_E_Pa,
                        "element_sections": None,
                        "use_rigid_diaphragm": False,
                    },
                    "Final": {
                        "df_worst": df_worst_final,
                        "walls": optimized_walls,
                        "wall_tw_mm": optimized_wall_tw_mm,
                        "wall_E_Pa": optimized_wall_E_Pa,
                        "element_sections": (jacketed_element_sections if "jacketed_element_sections" in locals() else None),
                        "use_rigid_diaphragm": False,
                    },
                }

                member_force_diagrams = collect_member_force_diagrams_for_report(
                    nodes=nodes,
                    elements=elements,
                    combos=combos,
                    combo_names=names,
                    Ec_Pa=Ec_Pa,
                    Es_Pa=Es_Pa,
                    column_sec=column_sec,
                    beam_sec=beam_sec,
                    geom=geom,
                    ops_build_model=ops_build_model,
                    ops_apply_combo_loads=ops_apply_combo_loads,
                    ops_run_static=ops_run_static,
                    target_member_ids=target_nvm_member_list,
                    npts=80,
                    stage_specs=nvm_stage_specs,
                )

                # Robust fallback: if the EC2 worst tables do not contain a
                # governing-combination column, the primary collector cannot map
                # members to combinations.  In that case scan the ULS
                # combinations and store the exact OpenSees diagram from the
                # most demanding real combination for each member and stage.
                if not member_force_diagrams:
                    print("N/V/M report collector did not find governing combo labels; scanning ULS combinations instead...")
                    member_force_diagrams = _collect_member_force_diagrams_by_uls_scan(
                        nodes=nodes,
                        elements=elements,
                        combos=combos,
                        combo_names=names,
                        Ec_Pa=Ec_Pa,
                        Es_Pa=Es_Pa,
                        column_sec=column_sec,
                        beam_sec=beam_sec,
                        geom=geom,
                        ops_build_model_fn=ops_build_model,
                        ops_apply_combo_loads_fn=ops_apply_combo_loads,
                        ops_run_static_fn=ops_run_static,
                        target_member_ids=target_nvm_member_list,
                        stage_specs=nvm_stage_specs,
                        npts=80,
                    )

                if member_force_diagrams:
                    n_nvm = sum(len(v) for v in member_force_diagrams.values())
                    print(f"✔ Collected exact station-by-station N/V/M report data for {n_nvm} member-stage cases.")
                else:
                    print("⚠ No exact N/V/M report data were collected; report will fall back to EC2 demand ordinates.")
            except Exception as exc:
                print(f"⚠ Could not collect exact N/V/M report data: {exc}")
                member_force_diagrams = None

            report = export_retrofit_optimization_report(
                output_dir="retrofit_report",
                drift_limit_ratio=drift_limit_ratio,
                df_static_drifts_before=df_all,
                sw_opt_df=sw_opt_df,
                global_opt_df=(global_opt_df if 'global_opt_df' in locals() else None),
                optimization_dataset_df=(optimization_dataset_df if 'optimization_dataset_df' in locals() else None),
                df_worst_before=df_worst,
                df_worst_after_walls=df_worst_after_sw,
                df_worst_final=df_worst_final,
                member_fail_after_walls=member_fail_after_sw,
                member_fail_final=member_fail_final,
                jacketing_trials_df=jacketing_trials_df,
                jacketing_member_report=(member_jacketing_report if "member_jacketing_report" in locals() else None),
                retrofit_cost_parameters=(retrofit_cost_parameters if "retrofit_cost_parameters" in locals() else None),
                jacket_cost=jacket_cost,
                nodes=nodes,
                elements=elements,
                geom=geom,
                base_walls=walls,
                selected_shear_wall_candidate=(sw_opt_df.iloc[0]["_candidate"] if sw_opt_df is not None and not sw_opt_df.empty and "_candidate" in sw_opt_df.columns else None),
                jacketed_member_ids=(all_jacketed_member_ids if "all_jacketed_member_ids" in locals() else failed_member_ids),
                jacketed_element_sections=(jacketed_element_sections if "jacketed_element_sections" in locals() else None),
                jacketing_iteration_worst_dfs=(jacketing_iteration_worst_dfs if "jacketing_iteration_worst_dfs" in locals() else None),
                column_sec=column_sec,
                beam_sec=beam_sec,
                member_force_diagrams=member_force_diagrams,
                logo_path=logo_path,
                student_name="Arman Hajiha",
                student_role="Research assistant at Politecnico di Torino",
                professor_name="Giuseppe Carlo Marano",
                report_title="Seismic Assessment and Retrofit Optimization Report",
                research_topic="AI and Structural Engineering",
            )
            print(f"✔ Excel report exported: {report.get('xlsx')}")
            if report.get("docx"):
                print(f"✔ Word report exported: {report.get('docx')}")
            elif report.get("docx_warning"):
                print(f"⚠ {report.get('docx_warning')}")

        print("\nRetrofit optimization stage completed.")